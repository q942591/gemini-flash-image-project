export default function PrivacyPolicy() {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8">
          Privacy Policy
        </h1>
        
        <div className="prose prose-lg max-w-none">
          <p className="text-gray-600 mb-8">
            Last updated: January 2025
          </p>
          
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">1. Overview</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              Gemini Flash Image ("we", "our", or "the service") is committed to protecting your privacy. This privacy policy explains how we collect, use, disclose, and protect the information you provide when using our service.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">2. Information We Collect</h2>
            <h3 className="text-xl font-medium text-gray-900 mb-3">2.1 Information You Provide Directly</h3>
            <ul className="list-disc list-inside text-gray-700 mb-4 space-y-2">
              <li>Account information (email address, username)</li>
              <li>Images you upload and editing instructions</li>
              <li>Contact information (when you contact us)</li>
            </ul>

            <h3 className="text-xl font-medium text-gray-900 mb-3">2.2 Automatically Collected Information</h3>
            <ul className="list-disc list-inside text-gray-700 mb-4 space-y-2">
              <li>Device information (browser type, operating system)</li>
              <li>Usage data (access time, page views)</li>
              <li>Information collected through cookies and similar technologies</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">3. How We Use Information</h2>
            <p className="text-gray-700 mb-4">We use the collected information to:</p>
            <ul className="list-disc list-inside text-gray-700 mb-4 space-y-2">
              <li>Provide and improve our services</li>
              <li>Process your image editing requests</li>
              <li>Communicate service-related information with you</li>
              <li>Analyze service usage for improvements</li>
              <li>Ensure service security and prevent fraud</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">4. Cookie Usage</h2>
            <p className="text-gray-700 mb-4">
              We use cookies and similar technologies to improve your user experience. You can control cookie usage through your browser settings or use the cookie preference settings on our website.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">5. Data Protection</h2>
            <p className="text-gray-700 mb-4">
              We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, use, or disclosure.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">6. Your Rights</h2>
            <p className="text-gray-700 mb-4">Under GDPR, you have the right to:</p>
            <ul className="list-disc list-inside text-gray-700 mb-4 space-y-2">
              <li>Access your personal data</li>
              <li>Correct inaccurate data</li>
              <li>Delete your data</li>
              <li>Restrict processing</li>
              <li>Data portability</li>
              <li>Object to processing</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">7. Contact Us</h2>
            <p className="text-gray-700 mb-4">
              If you have any questions about this privacy policy or need to exercise your rights, please contact us:
            </p>
            <p className="text-gray-700">
              Email: privacy@geminiflashimage.com
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}