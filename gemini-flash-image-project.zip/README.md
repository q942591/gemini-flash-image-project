# Gemini Flash Image

AI-powered image editing tool with natural language instructions.

## Setup Instructions

1. Install dependencies:
   ```bash
   npm install
   ```

2. Run the development server:
   ```bash
   npm run dev
   ```

3. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Features

- Natural language image editing
- Before/after comparison views
- EU GDPR compliant cookie consent
- Responsive design with Tailwind CSS
- Next.js 13 with App Router
- TypeScript support

## Tech Stack

- Next.js 13
- React 18
- TypeScript
- Tailwind CSS
- Shadcn/ui components
- Lucide React icons

## Project Structure

- `app/` - Next.js app router pages and API routes
- `components/` - React components
- `lib/` - Utility functions
- `public/` - Static assets

## Deployment

This project is configured for static export and can be deployed to any static hosting service.

```bash
npm run build
```

Built with ❤️ using Next.js and AI
