import FeatureDetail from '@/components/FeatureDetail'

export default function FeatureSection() {
  const features = [
    {
      title: "Natural Language Editing",
      description: "Achieve complex image editing operations with simple text descriptions. No need to learn complex editing software - let AI understand your ideas and complete the edits.",
      imageSrc: "https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=600",
      layoutDirection: "left" as const
    },
    {
      title: "Smart Object Recognition",
      description: "Advanced AI technology can accurately identify various objects, people, and scenes in images, providing powerful support for precise editing.",
      imageSrc: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=600",
      layoutDirection: "right" as const
    },
    {
      title: "One-Click Style Conversion",
      description: "Instantly change the artistic style of images, from realistic to cartoon, from modern to vintage - multiple styles at your choice.",
      imageSrc: "https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg?auto=compress&cs=tinysrgb&w=600",
      layoutDirection: "left" as const
    },
    {
      title: "Real-time Preview Effects",
      description: "Visualized editing process with real-time preview of modification effects. Support multiple adjustments until you're satisfied.",
      imageSrc: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=600",
      layoutDirection: "right" as const
    }
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
            Explore the Infinite Possibilities of
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Gemini Flash Image
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Revolutionary AI technology that makes image editing simple and intuitive
          </p>
        </div>

        <div className="space-y-20">
          {features.map((feature, index) => (
            <FeatureDetail
              key={index}
              title={feature.title}
              description={feature.description}
              imageSrc={feature.imageSrc}
              layoutDirection={feature.layoutDirection}
            />
          ))}
        </div>
      </div>
    </section>
  )
}