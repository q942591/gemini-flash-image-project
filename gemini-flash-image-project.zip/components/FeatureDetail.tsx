interface FeatureDetailProps {
  title: string
  description: string
  imageSrc: string
  layoutDirection: 'left' | 'right'
}

export default function FeatureDetail({
  title,
  description,
  imageSrc,
  layoutDirection
}: FeatureDetailProps) {
  const isImageLeft = layoutDirection === 'left'

  return (
    <div className={`flex flex-col ${isImageLeft ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center gap-12 lg:gap-16`}>
      {/* Image */}
      <div className="flex-1 w-full">
        <div className="relative">
          <img
            src={imageSrc}
            alt={title}
            className="w-full h-64 lg:h-80 object-cover rounded-2xl shadow-xl"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 to-blue-600/10 rounded-2xl"></div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 space-y-6">
        <h3 className="text-2xl lg:text-4xl font-bold text-gray-900">
          {title}
        </h3>
        <p className="text-lg text-gray-600 leading-relaxed">
          {description}
        </p>
        <div className="flex items-center space-x-4">
          <div className="w-12 h-1 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full"></div>
          <span className="text-sm text-purple-600 font-medium">
            Try Now
          </span>
        </div>
      </div>
    </div>
  )
}